const express = require('express');
const Lc = require('../models/lcModel');
const Extension = require('../models/extensionModel');
const Supplier = require('../models/supplierModel');
const auth = require('../middleware/auth');
const router = new express.Router();

// Get all extensions
router.get('', auth(), async (req, res) => {
	try {
		const extensions = await Extension.find();
		res.send(extensions);
	} catch (e) {
		res.status(500).send();
	}
});

// Get extension by id
router.get('/:id', auth(), async ({ params }, res) => {
	try {
		const extension = await Extension.findById(params.id);
		if (!extension) {
			throw new Error();
		}
		res.send(extension);
	} catch (e) {
		res.status(404).send();
	}
});

// Get extensions for specific lcs
router.get('/lc/:lcId', auth(), async ({ params }, res) => {
	try {
		const lc = await Lc.findById(params.lcId);
		if (!lc) {
			throw new Error();
		}
		await lc.populate('extensions').execPopulate();
		res.send(lc.extensions);
	} catch (e) {
		res.status(404).send();
	}
});
// Get extensions for specific supplier
router.get('/supplier/:supplierId', auth(), async ({ params }, res) => {
	try {
		const supplier = await Supplier.findById(params.supplierId);
		if (!supplier) {
			throw new Error('supplier not found for extesnion');
		}
		await supplier
			.populate({
				path: 'contracts',
				populate: { path: 'lcs', populate: { path: 'extensions' } },
			})
			.execPopulate();
		const lcs = [];
		for (let doc of supplier.contracts) {
			lcs.push(...doc.lcs);
		}
		const extensions = [];
		for (let doc of lcs) {
			extensions.push(...doc.extensions);
		}
		res.send(extensions);
	} catch (e) {
		res.status(404).send(e);
	}
});

// Get extensions for specific contract
router.get('/contract/:contractId', auth(), async ({ params }, res) => {
	try {
		const contract = await Contract.findById(params.contractId);
		if (!contract) {
			throw new Error();
		}
		await contract.populate({ path: 'lcs', populate: { path: 'extensions' } }).execPopulate();
		const extensions = [];
		for (let doc of contract.lcs) {
			extensions.push(...doc.extensions);
		}
		res.send(extensions);
	} catch (e) {
		res.status(404).send();
	}
});

// Edit extension data
router.patch('', auth({ canAddLc: true }), async ({ body }, res) => {
	const updates = {};
	const allowedUpdates = ['upTo', 'notes'];
	allowedUpdates.map(update => (updates[update] = body[update]));
	try {
		const extension = await Extension.findByIdAndUpdate(body._id, updates, {
			new: true,
			runValidators: true,
		});
		if (!extension) {
			throw new Error();
		}
		res.send(extension);
	} catch (e) {
		res.status(400).send(e);
	}
});

module.exports = router;
